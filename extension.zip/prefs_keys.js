var AUTO_LOCATION = 'auto-location';
var CALCULATION_METHOD = 'calculation-method';
var LATITUDE = 'latitude';
var LONGITUDE = 'longitude';
var TIMEZONE = 'timezone';
var TIME_FORMAT_12 = 'time-format-12';
var CONCISE_LIST = 'concise-list';
